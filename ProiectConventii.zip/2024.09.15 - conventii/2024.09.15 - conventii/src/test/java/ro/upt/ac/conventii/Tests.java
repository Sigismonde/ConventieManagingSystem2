package ro.upt.ac.conventii;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tests 
{
	@Test
	void contextLoads() 
	{
	}
}
